from MapCollection.MapCollection import MapCollection
